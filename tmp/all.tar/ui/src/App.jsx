import { useCallback } from 'react';
import { useWebSocket, apiPost } from './hooks/useWebSocket.js';
import TopBar from './components/TopBar.jsx';
import WorldCanvas from './components/WorldCanvas.jsx';
import Sidebar from './components/Sidebar.jsx';
import ControlBar from './components/ControlBar.jsx';
import './App.css';

export default function App() {
  const { simState, connected } = useWebSocket();

  const handleCanvasClick = useCallback(async (col, row) => {
    await apiPost('/goal', { col, row });
  }, []);

  return (
    <div className="app-shell">
      <TopBar connected={connected} />

      <div className="app-body">
        <div className="canvas-area">
          <WorldCanvas simState={simState} onCanvasClick={handleCanvasClick} />
          <ControlBar simState={simState} connected={connected} />
        </div>
        <Sidebar simState={simState} />
      </div>
    </div>
  );
}
